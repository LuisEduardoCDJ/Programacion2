﻿namespace Controlador
{
    public class Calcular
    {
        public int Sumar(int num1, int num2)
        {
            return num1 + num2;
        }
    }
}