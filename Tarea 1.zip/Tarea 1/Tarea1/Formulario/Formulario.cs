namespace Formulario
{
    public partial class Formulario : Form
    {
        public Formulario()
        {
            InitializeComponent();
            this.CenterToParent();
            this.Text = ("Formulario");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}