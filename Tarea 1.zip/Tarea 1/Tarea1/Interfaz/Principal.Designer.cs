﻿namespace Interfaz
{
    partial class Principal
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CalcuC = new System.Windows.Forms.Button();
            this.FormC = new System.Windows.Forms.Button();
            this.ImagenH = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // CalcuC
            // 
            this.CalcuC.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.CalcuC.Location = new System.Drawing.Point(12, 138);
            this.CalcuC.Name = "CalcuC";
            this.CalcuC.Size = new System.Drawing.Size(141, 48);
            this.CalcuC.TabIndex = 0;
            this.CalcuC.Text = "Calculadora";
            this.CalcuC.UseVisualStyleBackColor = true;
            this.CalcuC.Click += new System.EventHandler(this.button1_Click);
            // 
            // FormC
            // 
            this.FormC.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.FormC.Location = new System.Drawing.Point(188, 138);
            this.FormC.Name = "FormC";
            this.FormC.Size = new System.Drawing.Size(147, 48);
            this.FormC.TabIndex = 1;
            this.FormC.Text = "Formulario";
            this.FormC.UseVisualStyleBackColor = true;
            this.FormC.Click += new System.EventHandler(this.button2_Click);
            // 
            // ImagenH
            // 
            this.ImagenH.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ImagenH.Location = new System.Drawing.Point(371, 138);
            this.ImagenH.Name = "ImagenH";
            this.ImagenH.Size = new System.Drawing.Size(147, 48);
            this.ImagenH.TabIndex = 2;
            this.ImagenH.Text = "Imagen";
            this.ImagenH.UseVisualStyleBackColor = true;
            this.ImagenH.Click += new System.EventHandler(this.ImagenH_Click);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox1.Location = new System.Drawing.Point(158, 37);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(196, 50);
            this.textBox1.TabIndex = 3;
            this.textBox1.Text = "Hola Mundo!";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(555, 235);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.ImagenH);
            this.Controls.Add(this.FormC);
            this.Controls.Add(this.CalcuC);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button CalcuC;
        private Button FormC;
        private Button ImagenH;
        private TextBox textBox1;
    }
}