using System;
using System.Collections.Generic;
using calculadora;
using Formulario;
using Imagen;

namespace Interfaz
{
    public partial class Principal : Form
    {
      
        public Principal()
        {
            InitializeComponent();
            this.CenterToParent();
            this.Text = ("Principal");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Calculafora fm = new Calculafora();
            
            this.Hide();
            fm.Show();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Formulario.Formulario fm = new Formulario.Formulario();
            this.Hide();
            fm.Show();

        }
        private void ImagenH_Click(object sender, EventArgs e)
        {
            Imagen.Imagen im = new Imagen.Imagen();
            this.Hide();
            im.Show();
        }
    }
}