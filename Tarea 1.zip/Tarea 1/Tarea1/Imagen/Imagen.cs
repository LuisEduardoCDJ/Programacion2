namespace Imagen
{
    public partial class Imagen : Form
    {
        public Imagen()
        {
            InitializeComponent();
            this.CenterToParent();
            this.Text = ("Imagen");
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}