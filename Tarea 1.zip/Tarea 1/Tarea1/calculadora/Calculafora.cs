using System;

namespace calculadora
{
    public partial class Calculafora : Form
    {
        double sum1 = 0, sum2 = 0;
        char operador;

        public Calculafora()
        {
            InitializeComponent();
        }

        private void agregarnumero(object sender, EventArgs e)
        {
            var boton = ((Button)sender);
           
            if (Resultado.Text == "0")
                Resultado.Text = "0";
            Resultado.Text = boton.Text;
        }

        private void b0_Click(object sender, EventArgs e)
        {
            var boton = ((Button)sender);

            if (Resultado.Text == "0")
                Resultado.Text = "0";
            Resultado.Text = boton.Text;
        }

        private void Clickoperador(object sender, EventArgs e)
        {
            var boton = ((Button)sender);

            sum1 = Convert.ToDouble(Resultado.Text);
            operador = Convert.ToChar(boton.Tag);

            Resultado.Text = "0";
        }

        private void MenuC_Click(object sender, EventArgs e)
        {
            
        }

        private void sum_Click(object sender, EventArgs e)
        {
            sum1 = Convert.ToDouble(Resultado.Text);
            operador = '+';
        }
    }
}