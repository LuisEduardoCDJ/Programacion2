﻿namespace calculadora
{
    partial class Calculafora
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.Del = new System.Windows.Forms.Button();
            this.Divi = new System.Windows.Forms.Button();
            this.mult = new System.Windows.Forms.Button();
            this.res = new System.Windows.Forms.Button();
            this.sum = new System.Windows.Forms.Button();
            this.igual = new System.Windows.Forms.Button();
            this.b0 = new System.Windows.Forms.Button();
            this.punto = new System.Windows.Forms.Button();
            this.ExitC = new System.Windows.Forms.Button();
            this.Resultado = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(32, 257);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(55, 57);
            this.button1.TabIndex = 0;
            this.button1.Text = "1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.agregarnumero);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(107, 257);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(55, 57);
            this.button2.TabIndex = 1;
            this.button2.Text = "2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.agregarnumero);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(184, 257);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(55, 57);
            this.button3.TabIndex = 2;
            this.button3.Text = "3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.agregarnumero);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(32, 194);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(55, 57);
            this.button4.TabIndex = 3;
            this.button4.Text = "4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.agregarnumero);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(107, 194);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(55, 57);
            this.button5.TabIndex = 4;
            this.button5.Text = "5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.agregarnumero);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(184, 194);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(55, 57);
            this.button6.TabIndex = 5;
            this.button6.Text = "6";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.agregarnumero);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(32, 131);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(55, 57);
            this.button7.TabIndex = 6;
            this.button7.Text = "7";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.agregarnumero);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(107, 131);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(55, 57);
            this.button8.TabIndex = 7;
            this.button8.Text = "8";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.agregarnumero);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(184, 131);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(55, 57);
            this.button9.TabIndex = 8;
            this.button9.Text = "9";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.agregarnumero);
            // 
            // Del
            // 
            this.Del.Location = new System.Drawing.Point(32, 68);
            this.Del.Name = "Del";
            this.Del.Size = new System.Drawing.Size(55, 57);
            this.Del.TabIndex = 9;
            this.Del.Text = "DEL";
            this.Del.UseVisualStyleBackColor = true;
            // 
            // Divi
            // 
            this.Divi.Location = new System.Drawing.Point(107, 68);
            this.Divi.Name = "Divi";
            this.Divi.Size = new System.Drawing.Size(55, 57);
            this.Divi.TabIndex = 10;
            this.Divi.Tag = "/";
            this.Divi.Text = "/";
            this.Divi.UseVisualStyleBackColor = true;
            this.Divi.Click += new System.EventHandler(this.Clickoperador);
            // 
            // mult
            // 
            this.mult.Location = new System.Drawing.Point(184, 68);
            this.mult.Name = "mult";
            this.mult.Size = new System.Drawing.Size(55, 57);
            this.mult.TabIndex = 11;
            this.mult.Tag = "*";
            this.mult.Text = "*";
            this.mult.UseVisualStyleBackColor = true;
            this.mult.Click += new System.EventHandler(this.Clickoperador);
            // 
            // res
            // 
            this.res.Location = new System.Drawing.Point(259, 68);
            this.res.Name = "res";
            this.res.Size = new System.Drawing.Size(55, 57);
            this.res.TabIndex = 12;
            this.res.Tag = "-";
            this.res.Text = "-";
            this.res.UseVisualStyleBackColor = true;
            this.res.Click += new System.EventHandler(this.Clickoperador);
            // 
            // sum
            // 
            this.sum.Location = new System.Drawing.Point(259, 131);
            this.sum.Name = "sum";
            this.sum.Size = new System.Drawing.Size(55, 88);
            this.sum.TabIndex = 13;
            this.sum.Tag = "+";
            this.sum.Text = "+";
            this.sum.UseVisualStyleBackColor = true;
            this.sum.Click += new System.EventHandler(this.Clickoperador);
            // 
            // igual
            // 
            this.igual.Location = new System.Drawing.Point(259, 226);
            this.igual.Name = "igual";
            this.igual.Size = new System.Drawing.Size(55, 88);
            this.igual.TabIndex = 14;
            this.igual.Tag = "=";
            this.igual.Text = "=";
            this.igual.UseVisualStyleBackColor = true;
            this.igual.Click += new System.EventHandler(this.Clickoperador);
            // 
            // b0
            // 
            this.b0.Location = new System.Drawing.Point(32, 320);
            this.b0.Name = "b0";
            this.b0.Size = new System.Drawing.Size(130, 52);
            this.b0.TabIndex = 15;
            this.b0.Text = "0";
            this.b0.UseVisualStyleBackColor = true;
            this.b0.Click += new System.EventHandler(this.b0_Click);
            // 
            // punto
            // 
            this.punto.Location = new System.Drawing.Point(184, 320);
            this.punto.Name = "punto";
            this.punto.Size = new System.Drawing.Size(130, 52);
            this.punto.TabIndex = 16;
            this.punto.Tag = ".";
            this.punto.Text = ".";
            this.punto.UseVisualStyleBackColor = true;
            this.punto.Click += new System.EventHandler(this.Clickoperador);
            // 
            // ExitC
            // 
            this.ExitC.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ExitC.Location = new System.Drawing.Point(107, 392);
            this.ExitC.Name = "ExitC";
            this.ExitC.Size = new System.Drawing.Size(130, 46);
            this.ExitC.TabIndex = 18;
            this.ExitC.Text = "Exit";
            this.ExitC.UseVisualStyleBackColor = true;
            // 
            // Resultado
            // 
            this.Resultado.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Resultado.Location = new System.Drawing.Point(32, 12);
            this.Resultado.MaxLength = 21;
            this.Resultado.Multiline = true;
            this.Resultado.Name = "Resultado";
            this.Resultado.ReadOnly = true;
            this.Resultado.Size = new System.Drawing.Size(282, 50);
            this.Resultado.TabIndex = 19;
            this.Resultado.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Calculafora
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(365, 450);
            this.Controls.Add(this.Resultado);
            this.Controls.Add(this.ExitC);
            this.Controls.Add(this.punto);
            this.Controls.Add(this.b0);
            this.Controls.Add(this.igual);
            this.Controls.Add(this.sum);
            this.Controls.Add(this.res);
            this.Controls.Add(this.mult);
            this.Controls.Add(this.Divi);
            this.Controls.Add(this.Del);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Calculafora";
            this.Text = "0";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button Del;
        private Button Divi;
        private Button mult;
        private Button res;
        private Button sum;
        private Button igual;
        private Button b0;
        private Button punto;
        private Button ExitC;
        private TextBox Resultado;
    }
}