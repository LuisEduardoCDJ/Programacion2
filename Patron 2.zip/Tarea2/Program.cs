﻿using System;

namespace Tarea2
{
    class Program
    {
        static void Main(string[] args)
        {
            Empleados.Registrado = DateTime.Now.ToString("hh:mm:ss");
            Empleados.DiaRegistrp = DateTime.Now.ToString("D");

            Console.WriteLine("Introduzca sus datos:");
            Console.WriteLine("Digite su nombre:");
            Empleados.Nombre = Console.ReadLine();
            Console.WriteLine("Digite su apellido:");
            Empleados.Apellido = Console.ReadLine();
            Console.WriteLine("Digite su cedula:");
            Empleados.Cedula = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite su fecha de ancimiento:\nEjmeplo: 2002-07-11\n");
            Empleados.Fecha_Nacimiento = Console.ReadLine();
            Console.WriteLine("Digite su Departamento:");
            Empleados.Departamneto = Console.ReadLine();
            Console.WriteLine("Digite su Sueldo:");
            Empleados.Sueldo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Digite su celular:");
            Empleados.Celular = int.Parse(Console.ReadLine());
            
            Console.WriteLine("Digite su tipo de empleados:\n-Tiempo Completo\n-Tiempo Medio\n-Temporero");
            string mf = Console.ReadLine();

            ITipos_Empleados Tipo = Fabrica_Empleados.GetEmpleados(mf);

            Tipo.Precio_X_Hora();
            Tipo.Horas_X_Dias();
            Tipo.Forma_Pago();
            Tipo.Tipo();

            if (mf == "Tiempo Completo" || mf == "Tiempo Medio")
            {
                Console.WriteLine("Numero de cuenta:");
                Empleados.Cuenta = Convert.ToInt32(Console.ReadLine());
            }
            else 
            {
                Empleados.Cuenta = 0;
            }
            BaseD.Documento();
        }
    }
}
