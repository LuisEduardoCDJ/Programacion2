﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Tarea2
{
    class BaseD
    {
        public static void Documento() 
        {
            TextWriter textbd;

            textbd = new StreamWriter("Texto.txt");

            textbd.WriteLine("Datos Personales:");
            textbd.WriteLine("Nombre: "+Empleados.Nombre);
            textbd.WriteLine("Apellido: "+Empleados.Apellido);
            textbd.WriteLine("Cedula o RNC: " + Empleados.Cedula);
            textbd.WriteLine("Fecha de Nacimiento: "+Empleados.Fecha_Nacimiento);
            textbd.WriteLine("Area Laboral o Departamento: "+Empleados.Departamneto);
            textbd.WriteLine("Sueldo: "+Empleados.Sueldo);
            textbd.WriteLine("Celular: "+Empleados.Celular);
            textbd.WriteLine("Precio por horas: "+Empleados.PrecioPorHoras);
            textbd.WriteLine("Precio por dias: "+Empleados.GanaciaPorDia);
            textbd.WriteLine("Forma de pagos: "+Empleados.GanaciaPorDia);
            textbd.WriteLine("Numero de cuenta: "+Empleados.Cuenta);
            textbd.WriteLine("Hora de registro: "+Empleados.Registrado);
            textbd.WriteLine("Dia de registro: "+Empleados.DiaRegistrp);

            textbd.Close();
        }
    }
}
