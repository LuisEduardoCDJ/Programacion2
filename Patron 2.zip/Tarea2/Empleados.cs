﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tarea2
{
    class Empleados
    {
        public static string Nombre { get; set; }
        public static string Apellido { get; set; }
        public static int Cedula { get; set; }
        public static string Fecha_Nacimiento { get; set; }
        public static string Departamneto { get; set; }
        public static int Celular { get; set; }
        public static int Cuenta { get; set; }
        public static int PrecioPorHoras { get;set; }
        public static string TiposEmpleados { get;set; }
        public static int Sueldo { get; set; }
        public static int GanaciaPorDia { get; set; }
        public static string FormaPagos { get; set; }
        public static string TEmpleados { get; set; }
        public static string Registrado { get; set; }
        public static string DiaRegistrp { get; set; }
    }
}
