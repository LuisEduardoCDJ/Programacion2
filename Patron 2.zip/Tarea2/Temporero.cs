﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tarea2
{
    class Temporero : ITipos_Empleados
    {
        public void Tipo()
        {
            Empleados.TEmpleados = "Temporero";
        }
        public void Forma_Pago()
        {
            Empleados.FormaPagos = "Por Cheques";
        }
        public void Precio_X_Hora()
        {
            Empleados.PrecioPorHoras = (int)((Convert.ToDouble(Empleados.Sueldo)) / 23.83) / 8;
        }
        public void Horas_X_Dias()
        {
            Empleados.PrecioPorHoras = 8;
        }
    }
}
