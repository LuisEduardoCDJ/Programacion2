﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tarea2
{
    class Fabrica_Empleados
    {
        public static ITipos_Empleados GetEmpleados(string TiposDeEmpleados) 
        {
            if (TiposDeEmpleados == "Tiempo Completo")
            {
                return new TCompleto();
            }
            if (TiposDeEmpleados == "Tiempo Medio")
            {
                return new TMedio();
            }
            else { return new Temporero(); }
        }

    }
}
