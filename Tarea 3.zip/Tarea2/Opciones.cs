﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tarea2
{
    class Opciones
    {
        public static void menu()
        {
            Console.WriteLine("Digite Una Opcion:\n1: Registro\n2: Vacaciones\n3: Permiso\n4: Renunciar.\n5: Salir");
            string a = Console.ReadLine();
            int b = int.Parse(a);
            if (b == 1)
            {
                RegistroE.Registro();
            }
            if (b == 2)
            {
                Vacaciones.vacion();
            }
            if (b == 3)
            {
                Permiso.Permisos();
            }
            if (b == 4)
            {
                Desvinculacion.desvinc();
            }
            else { Console.ReadKey(); }
        }
    }
}
