﻿using System;
using System.Diagnostics;

namespace Tarea2
{
    class Program
    {
        public static void Main(string[] args)
        {
            Opciones.menu();
        }
    };
}
