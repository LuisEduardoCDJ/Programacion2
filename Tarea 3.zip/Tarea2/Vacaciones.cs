﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Tarea2
{
    class Vacaciones 
    {
        public static void vacion() 
        {
            DateTime date1, date2;
            int cedul;
            Console.WriteLine("Digite su cedula:");
            cedul = int.Parse(Console.ReadLine());

          
            if (cedul == Empleados.Cedula) 
            { 
            Console.WriteLine("Fecha Inicio de vaciones:");
            date1 = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("Fecha Final de vaciones:");
            date2 = Convert.ToDateTime(Console.ReadLine());
            TimeSpan difdays = date2.Subtract(date1);
            Console.WriteLine("Dias Total de Vaciones: " + difdays);
            int op;
            Console.WriteLine("1) Menu.\n2) Salir.");
            op = Convert.ToInt32(Console.ReadLine());
            if (op == 1)
            {
                Opciones.menu();
            }
            else { Console.ReadKey(); }
            }
            else { Console.WriteLine("Empleado no se encuentra. Por favor registrese."); Opciones.menu(); }
        }
    }
}
