﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tarea2
{
    class Desvinculacion 
    {
        public static void desvinc()
        {
            int cedul;
            string causa;

            Console.WriteLine("Digite su cedula:");
            cedul = int.Parse(Console.ReadLine());

            if (cedul == (Empleados.Cedula))
            {
                Console.WriteLine("Cual es su causa:");
                causa = Console.ReadLine();
            }
            else { Console.WriteLine("No existe este usurario."); Opciones.menu(); }
            

        }
    }
}
