﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tarea2
{
    class TCompleto : ITipos_Empleados
    {
        public void Tipo()
        {
            Empleados.TEmpleados = "Tiempo Completo";
        }
        public void Forma_Pago() 
        {
            Empleados.FormaPagos = "Numero de cuenta de banco";
        }
        public void Precio_X_Hora() 
        {
            Empleados.PrecioPorHoras = (int)((Convert.ToDouble(Empleados.Sueldo))/23.83)/8;
        }
        public void Horas_X_Dias() 
        {
            Empleados.Horas = 8;
        }
    }
}
