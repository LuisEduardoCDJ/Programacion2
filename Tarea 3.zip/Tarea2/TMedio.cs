﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tarea2
{
    class TMedio : ITipos_Empleados
    {
        public void Tipo()
        {
            Empleados.TEmpleados = "Medio Tiempo";
        }
        public void Forma_Pago()
        {
            Empleados.FormaPagos = "Numero de cuenta de banco";
        }
        public void Precio_X_Hora()
        {
            Empleados.PrecioPorHoras = (int)((Convert.ToDouble(Empleados.Sueldo)) / 23.83) / 4;
        }
        public void Horas_X_Dias()
        {
            Empleados.Horas = 4;
        }
    }
}
