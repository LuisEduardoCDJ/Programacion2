﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tarea2
{
    class Permiso
    {
        public static void Permisos() 
        {
            DateTime fecha1;
            DateTime fecha2;
            Console.WriteLine("Digite la fecha actual: ");
            fecha1 = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("Digite la fecha que desea el permiso: ");
            fecha2 = Convert.ToDateTime(Console.ReadLine());
            TimeSpan diff = fecha2.Subtract(fecha1);
            Console.WriteLine($"Los dias que debes son: {diff}.\nBuenas suerte. ");

            int op;
            Console.WriteLine("1) MENU \n2) SALIR");
            op = int.Parse(Console.ReadLine());
            if (op == 1) { Opciones.menu(); }
            else { Console.ReadKey();}
        }
    }
}
