﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tarea2
{
    interface ITipos_Empleados
    {   
        void Tipo();
        void Forma_Pago();
        void Precio_X_Hora();
        void Horas_X_Dias();
    };
}
