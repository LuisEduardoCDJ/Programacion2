﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tarea2
{
    class RegistroE 
    {
        public static void Registro()
        {
            string a;
            string b;
          
            Console.WriteLine("Introduzca sus datos:");
            Console.WriteLine("Digite su nombre:");
            a = Console.ReadLine();
            Empleados.Nombre = a;
            Console.WriteLine("Digite su cedula:");
            Empleados.Cedula = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite su fecha de ancimiento:\nEjmeplo: 2002-07-11\n");
            Empleados.Fecha_Nacimiento = Console.ReadLine();
            Console.WriteLine("Digite su Departamento:");
            Empleados.Departamneto = Console.ReadLine();
            Console.WriteLine("Digite su Sueldo:");
            Empleados.Sueldo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Digite su celular:");
            Empleados.Celular = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite su tipo de empleados:\n1-Tiempo Completo\n2-Tiempo Medio\n3-Temporero");
            string mf = Console.ReadLine();
            

            ITipos_Empleados Tipo = Fabrica_Empleados.GetEmpleados(mf);

            Tipo.Precio_X_Hora();
            Tipo.Horas_X_Dias();
            Tipo.Forma_Pago();
            Tipo.Tipo();

            if (mf == "1")
            {
                Empleados.TiposEmpleados = "Tiempo Completo";
                string pago = "Transferencia Bancaria";
                Empleados.Horas = 8;
                Empleados.FormaPagos = pago;
                Console.WriteLine("Numero de cuenta:");
                Empleados.Cuenta = Convert.ToInt32(Console.ReadLine());
                Console.Clear();
                Console.WriteLine("Registro Exitoso.");
                Texto.TextO();
                Opciones.menu();
            }
            if (mf == "2")
            {
                Empleados.TiposEmpleados = "Medio Tiempo";
                string pago = "Transferencia Bancaria";
                Empleados.Horas = 4;
                Empleados.FormaPagos = pago;
                Console.WriteLine("Numero de cuenta:");
                Empleados.Cuenta = Convert.ToInt32(Console.ReadLine());
                Console.Clear();
                Console.WriteLine("Registro Exitoso.");
                Texto.TextO();
                Opciones.menu();
            }
            if (mf == "3")
            {
                Empleados.TiposEmpleados = "Temporero";
                string pago = "Pago en cheque";
                Empleados.Horas = 8;
                Empleados.FormaPagos = pago;
                Empleados.Cuenta = 0;
                Console.Clear();
                Console.WriteLine("Registro Exitoso.");
                Texto.TextO();
                Opciones.menu();
            }
            else { Console.ReadKey(); Opciones.menu(); }
        }
    };
}
