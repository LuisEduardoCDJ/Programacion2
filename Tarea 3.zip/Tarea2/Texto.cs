﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Tarea2
{
     class Texto
    {
        public static void TextO()
        { 
            StreamWriter Logs = File.AppendText("Archivo.txt");
           
            Logs.WriteLine("****Datos Del Empleado****");
            Logs.WriteLine("Nombre: " + Empleados.Nombre);
            Logs.WriteLine("Cedula o RNC: " + Empleados.Cedula);
            Logs.WriteLine("Fecha de Nacimiento: " + Empleados.Fecha_Nacimiento);
            Logs.WriteLine("Area Laboral: " + Empleados.Departamneto);
            Logs.WriteLine("Sueldo: " + Empleados.Sueldo);
            Logs.WriteLine("Forma de pago: " + Empleados.FormaPagos);
            Logs.WriteLine("Numero de cuenta: " + Empleados.Cuenta);
            Logs.WriteLine("Hora de registro: " + Empleados.DiaRegistrp);
            Logs.WriteLine("Precio por horas; " + Empleados.PrecioPorHoras);
            Logs.WriteLine("Horas de Trabajo: " + Empleados.Horas);
            Logs.WriteLine("");
            Logs.Close();
        }
    }
}
